package com.satesoft.tenant_theming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TenantThemingApplicationTests {

	@Test
	void contextLoads() {
	}

}
